from distutils.core import setup

setup(name = 'Cliques',
      version = '1.0',
      py_modules = ['all_maximal_cliques'], 
)
